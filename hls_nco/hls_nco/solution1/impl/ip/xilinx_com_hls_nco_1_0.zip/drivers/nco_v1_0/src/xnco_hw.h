// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// AXILiteS
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of sine_sample_V
//        bit 15~0 - sine_sample_V[15:0] (Read)
//        others   - reserved
// 0x14 : Control signal of sine_sample_V
//        bit 0  - sine_sample_V_ap_vld (Read/COR)
//        others - reserved
// 0x18 : Data signal of step_size_V
//        bit 15~0 - step_size_V[15:0] (Read/Write)
//        others   - reserved
// 0x1c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XNCO_AXILITES_ADDR_SINE_SAMPLE_V_DATA 0x10
#define XNCO_AXILITES_BITS_SINE_SAMPLE_V_DATA 16
#define XNCO_AXILITES_ADDR_SINE_SAMPLE_V_CTRL 0x14
#define XNCO_AXILITES_ADDR_STEP_SIZE_V_DATA   0x18
#define XNCO_AXILITES_BITS_STEP_SIZE_V_DATA   16

